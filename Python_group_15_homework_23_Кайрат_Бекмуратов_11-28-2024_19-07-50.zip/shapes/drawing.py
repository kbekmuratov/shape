from shapes.rectangle import Rectangle
from shapes.square import Square
from shapes.circle import Circle
from shapes.triangle import Triangle
import turtle


class Drawing:
    def __init__(self):
        self.shapes = [
            Triangle("black", "dark blue", (-350, -50), 0, 300),
            Triangle("black", "white", (-245, 130), 0, 90),
            Square("black", "yellow", (-50, -50), 0, 100),
            Triangle("black", "brown", (-70, 45), 0, 140),
            Rectangle("black", "blue", (15, 10), 0, 30, 30),
            Rectangle("black", "blue", (-45, 10), 0, 30, 30),
            Rectangle("black", "red", (-10, -15), 0, 20, 35),
            Circle("black", "yellow", (150, 150), 0, 50),
            Rectangle("black", "green", (-600, -50), 0, 1200, 450),
            Rectangle("brown", "brown", (180, 25), 0, 10, 80),
            Circle("green", "green", (180, -40), 0, 40),

        ]

    def draw(self):
        for shape in self.shapes:
            print(shape)
            shape.draw()
        turtle.done()


if __name__ == "__main__":
    turtle.speed(5)
    drawing = Drawing()
    drawing.draw()

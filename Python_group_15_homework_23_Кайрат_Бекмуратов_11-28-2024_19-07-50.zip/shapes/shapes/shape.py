import turtle


class Shape:
    def __init__(self, border, fill, coordinates, heading):
        self.border = border
        self.fill = fill
        self.coordinates = coordinates
        self.heading = heading

    def draw(self):
        turtle.penup()
        turtle.goto(self.coordinates)
        turtle.setheading(self.heading)
        turtle.pendown()
        turtle.color(self.border, self.fill)
        print(f'Drawing shape at {
              self.coordinates} with heading {self.heading}')

    def __str__(self):
        return (f"Shape  {self.coordinates}, heading: {self.heading}°, "
                f"border color: {self.border}, fill color: {self.fill}")

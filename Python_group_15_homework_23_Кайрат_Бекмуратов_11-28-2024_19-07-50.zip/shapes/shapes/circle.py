from shapes.shape import Shape
import turtle


class Circle(Shape):
    def __init__(self, border, fill, coordinates, heading, radius):
        super().__init__(border, fill, coordinates, heading)
        self.radius = radius

    def draw(self):
        super().draw()
        turtle.begin_fill()
        turtle.circle(self.radius)
        turtle.end_fill()

    def __str__(self):
        return (f"Circle at {self.coordinates}, radius: {self.radius}, "
                f"border color: {self.border}, fill color: {self.fill}")

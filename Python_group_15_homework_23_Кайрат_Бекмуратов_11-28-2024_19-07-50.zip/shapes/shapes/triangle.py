from shapes.shape import Shape
import turtle
import math


class Triangle(Shape):
    def __init__(self, border, fill, coordinates, heading, side_length):
        super().__init__(border, fill, coordinates, heading)
        self.side_length = side_length

    def draw(self):
        super().draw()
        turtle.begin_fill()
        for _ in range(3):
            turtle.forward(self.side_length)
            turtle.left(120)
        turtle.end_fill()

    def __str__(self):
        height = round(math.sqrt(3) / 2 * self.side_length, 2)
        return (f"Triangle at {self.coordinates} with side {self.side_length}, "
                f"height {height}, border color {self.border}, fill color {self.fill}")

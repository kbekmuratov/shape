from shapes.shape import Shape
import turtle


class Rectangle(Shape):
    def __init__(self, border, fill, coordinates, heading, width, height):
        super().__init__(border, fill, coordinates, heading)
        self.width = width
        self.height = height

    def draw(self):
        super().draw()
        turtle.begin_fill()
        turtle.forward(self.width)
        turtle.right(90)
        turtle.forward(self.height)
        turtle.right(90)
        turtle.forward(self.width)
        turtle.right(90)
        turtle.forward(self.height)
        turtle.right(90)
        turtle.end_fill()

    def __str__(self):
        return (f"Rectangle at {self.coordinates}, width: {self.width}, height: {self.height}, "
                f"border color: {self.border}, fill color: {self.fill}")

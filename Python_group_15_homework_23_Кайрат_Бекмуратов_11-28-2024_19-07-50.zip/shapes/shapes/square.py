from shapes.shape import Shape
import turtle


class Square(Shape):
    def __init__(self, border, fill, coordinates, heading, side_length):
        super().__init__(border, fill, coordinates, heading)
        self.side_length = side_length

    def draw(self):
        super().draw()
        turtle.begin_fill()
        for _ in range(4):
            turtle.forward(self.side_length)
            turtle.left(90)
        turtle.end_fill()

    def __str__(self):
        return (f"Square at {self.coordinates} with side {self.side_length}, "
                f"border color {self.border}, fill color {self.fill}")
